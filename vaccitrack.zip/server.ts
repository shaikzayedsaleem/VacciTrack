import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import crypto from "node:crypto";

const db = new Database("vaccitrack.db");

// Initialize Database Schema
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT CHECK(role IN ('Admin', 'Staff')) NOT NULL
  );

  CREATE TABLE IF NOT EXISTS vaccines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    manufacturer TEXT NOT NULL,
    quantity INTEGER DEFAULT 0,
    expiry_date TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS citizens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    dob TEXT NOT NULL,
    gender TEXT NOT NULL,
    phone TEXT NOT NULL,
    address TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    citizen_id INTEGER NOT NULL,
    vaccine_id INTEGER NOT NULL,
    appointment_date TEXT NOT NULL,
    status TEXT CHECK(status IN ('Scheduled', 'Completed', 'Cancelled')) DEFAULT 'Scheduled',
    FOREIGN KEY (citizen_id) REFERENCES citizens(id),
    FOREIGN KEY (vaccine_id) REFERENCES vaccines(id)
  );

  CREATE TABLE IF NOT EXISTS vaccinations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    citizen_id INTEGER NOT NULL,
    vaccine_id INTEGER NOT NULL,
    dose_number INTEGER NOT NULL,
    vaccination_date TEXT NOT NULL,
    FOREIGN KEY (citizen_id) REFERENCES citizens(id),
    FOREIGN KEY (vaccine_id) REFERENCES vaccines(id)
  );

  CREATE TABLE IF NOT EXISTS aefi_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    citizen_id INTEGER NOT NULL,
    description TEXT NOT NULL,
    report_date TEXT NOT NULL,
    FOREIGN KEY (citizen_id) REFERENCES citizens(id)
  );
`);

// Seed Admin if not exists
const adminCheck = db.prepare("SELECT * FROM users WHERE email = ?").get("admin@vaccitrack.com");
if (!adminCheck) {
  const hashedPassword = crypto.createHash("sha256").update("admin123").digest("hex");
  db.prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)").run(
    "System Admin",
    "admin@vaccitrack.com",
    hashedPassword,
    "Admin"
  );
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // --- AUTH API ---
  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    const hashedPassword = crypto.createHash("sha256").update(password).digest("hex");
    const user = db.prepare("SELECT id, name, email, role FROM users WHERE email = ? AND password = ?")
      .get(email, hashedPassword);
    
    if (user) {
      res.json(user);
    } else {
      res.status(401).json({ error: "Invalid credentials" });
    }
  });

  app.post("/api/auth/signup", (req, res) => {
    const { name, email, password, role } = req.body;
    const hashedPassword = crypto.createHash("sha256").update(password).digest("hex");
    try {
      const result = db.prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)")
        .run(name, email, hashedPassword, role || 'Staff');
      res.json({ id: result.lastInsertRowid, name, email, role });
    } catch (e) {
      res.status(400).json({ error: "Email already exists" });
    }
  });

  // --- DASHBOARD API ---
  app.get("/api/dashboard/stats", (req, res) => {
    const vaccines = db.prepare("SELECT COUNT(*) as count FROM vaccines").get().count;
    const citizens = db.prepare("SELECT COUNT(*) as count FROM citizens").get().count;
    const vaccinations = db.prepare("SELECT COUNT(*) as count FROM vaccinations").get().count;
    const appointments = db.prepare("SELECT COUNT(*) as count FROM appointments").get().count;
    const aefi = db.prepare("SELECT COUNT(*) as count FROM aefi_reports").get().count;
    res.json({ vaccines, citizens, vaccinations, appointments, aefi });
  });

  // --- VACCINES API ---
  app.get("/api/vaccines", (req, res) => {
    const list = db.prepare("SELECT * FROM vaccines").all();
    res.json(list);
  });

  app.post("/api/vaccines", (req, res) => {
    const { name, manufacturer, quantity, expiry_date } = req.body;
    const result = db.prepare("INSERT INTO vaccines (name, manufacturer, quantity, expiry_date) VALUES (?, ?, ?, ?)")
      .run(name, manufacturer, quantity, expiry_date);
    res.json({ id: result.lastInsertRowid, ...req.body });
  });

  app.delete("/api/vaccines/:id", (req, res) => {
    db.prepare("DELETE FROM vaccines WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  // --- CITIZENS API ---
  app.get("/api/citizens", (req, res) => {
    const list = db.prepare("SELECT * FROM citizens").all();
    res.json(list);
  });

  app.post("/api/citizens", (req, res) => {
    const { full_name, dob, gender, phone, address } = req.body;
    const result = db.prepare("INSERT INTO citizens (full_name, dob, gender, phone, address) VALUES (?, ?, ?, ?, ?)")
      .run(full_name, dob, gender, phone, address);
    res.json({ id: result.lastInsertRowid, ...req.body });
  });

  // --- APPOINTMENTS API ---
  app.get("/api/appointments", (req, res) => {
    const list = db.prepare(`
      SELECT a.*, c.full_name as citizen_name, v.name as vaccine_name 
      FROM appointments a
      JOIN citizens c ON a.citizen_id = c.id
      JOIN vaccines v ON a.vaccine_id = v.id
    `).all();
    res.json(list);
  });

  app.post("/api/appointments", (req, res) => {
    const { citizen_id, vaccine_id, appointment_date } = req.body;
    
    // Check stock
    const vaccine = db.prepare("SELECT quantity FROM vaccines WHERE id = ?").get(vaccine_id);
    if (!vaccine || vaccine.quantity <= 0) {
      return res.status(400).json({ error: "Vaccine out of stock" });
    }

    const result = db.prepare("INSERT INTO appointments (citizen_id, vaccine_id, appointment_date) VALUES (?, ?, ?)")
      .run(citizen_id, vaccine_id, appointment_date);
    res.json({ id: result.lastInsertRowid, ...req.body });
  });

  // --- VACCINATIONS API (TRANSACTIONAL) ---
  app.get("/api/vaccinations", (req, res) => {
    const list = db.prepare(`
      SELECT v.*, c.full_name as citizen_name, vac.name as vaccine_name 
      FROM vaccinations v
      JOIN citizens c ON v.citizen_id = c.id
      JOIN vaccines vac ON v.vaccine_id = vac.id
    `).all();
    res.json(list);
  });

  app.post("/api/vaccinations", (req, res) => {
    const { citizen_id, vaccine_id, dose_number, vaccination_date } = req.body;

    // Transaction logic
    const performVaccination = db.transaction((data) => {
      // 1. Check stock
      const vaccine = db.prepare("SELECT quantity FROM vaccines WHERE id = ?").get(data.vaccine_id);
      if (!vaccine || vaccine.quantity <= 0) {
        throw new Error("Insufficient stock");
      }

      // 2. Check duplicate dose
      const existing = db.prepare("SELECT id FROM vaccinations WHERE citizen_id = ? AND vaccine_id = ? AND dose_number = ?")
        .get(data.citizen_id, data.vaccine_id, data.dose_number);
      if (existing) {
        throw new Error("Dose already recorded for this citizen");
      }

      // 3. Record vaccination
      const result = db.prepare("INSERT INTO vaccinations (citizen_id, vaccine_id, dose_number, vaccination_date) VALUES (?, ?, ?, ?)")
        .run(data.citizen_id, data.vaccine_id, data.dose_number, data.vaccination_date);

      // 4. Decrease stock
      db.prepare("UPDATE vaccines SET quantity = quantity - 1 WHERE id = ?").run(data.vaccine_id);

      return result.lastInsertRowid;
    });

    try {
      const id = performVaccination({ citizen_id, vaccine_id, dose_number, vaccination_date });
      res.json({ id, success: true });
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  // --- AEFI API ---
  app.get("/api/aefi", (req, res) => {
    const list = db.prepare(`
      SELECT a.*, c.full_name as citizen_name 
      FROM aefi_reports a
      JOIN citizens c ON a.citizen_id = c.id
    `).all();
    res.json(list);
  });

  app.post("/api/aefi", (req, res) => {
    const { citizen_id, description, report_date } = req.body;
    const result = db.prepare("INSERT INTO aefi_reports (citizen_id, description, report_date) VALUES (?, ?, ?)")
      .run(citizen_id, description, report_date);
    res.json({ id: result.lastInsertRowid, ...req.body });
  });

  // --- VITE MIDDLEWARE ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`VacciTrack Server running on http://localhost:${PORT}`);
  });
}

startServer();
