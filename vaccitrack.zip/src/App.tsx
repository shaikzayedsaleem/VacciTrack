import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Syringe, 
  Users, 
  Calendar, 
  ShieldAlert, 
  LogOut, 
  Plus, 
  Search,
  Trash2,
  CheckCircle2,
  AlertCircle,
  FileBadge
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Vaccine, 
  Citizen, 
  Appointment, 
  Vaccination, 
  AEFIReport, 
  DashboardStats 
} from './types';

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active, onClick }: any) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-6 py-4 text-sm font-medium transition-colors ${
      active ? 'bg-black text-white' : 'hover:bg-black/5 text-black/60'
    }`}
  >
    <Icon size={18} />
    {label}
  </button>
);

const StatCard = ({ label, value, icon: Icon }: any) => (
  <div className="p-6 border border-black/10 bg-white/50 flex items-center justify-between">
    <div>
      <p className="col-header mb-1">{label}</p>
      <h3 className="text-3xl font-light data-value">{value}</h3>
    </div>
    <div className="text-black/20">
      <Icon size={32} />
    </div>
  </div>
);

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isSignUp, setIsSignUp] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Data states
  const [vaccines, setVaccines] = useState<Vaccine[]>([]);
  const [citizens, setCitizens] = useState<Citizen[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [vaccinations, setVaccinations] = useState<Vaccination[]>([]);
  const [aefi, setAefi] = useState<AEFIReport[]>([]);
  const [selectedCertId, setSelectedCertId] = useState<number | null>(null);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user, activeTab]);

  const fetchDashboardData = async () => {
    try {
      const [s, v, c, a, vac, ae] = await Promise.all([
        fetch('/api/dashboard/stats').then(r => r.json()),
        fetch('/api/vaccines').then(r => r.json()),
        fetch('/api/citizens').then(r => r.json()),
        fetch('/api/appointments').then(r => r.json()),
        fetch('/api/vaccinations').then(r => r.json()),
        fetch('/api/aefi').then(r => r.json()),
      ]);
      setStats(s);
      setVaccines(v);
      setCitizens(c);
      setAppointments(a);
      setVaccinations(vac);
      setAefi(ae);
    } catch (e) {
      console.error("Failed to fetch data", e);
    }
  };

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;

    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data);
      } else {
        setError('Invalid email or password');
      }
    } catch (e) {
      setError('Connection error');
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const name = formData.get('name') as string;
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;
    const role = formData.get('role') as string;

    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, role }),
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data);
      } else {
        const data = await res.json();
        setError(data.error || 'Failed to create account');
      }
    } catch (e) {
      setError('Connection error');
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md bg-white p-12 border border-black/10 shadow-2xl"
        >
          <div className="mb-12">
            <h1 className="text-4xl font-light tracking-tighter mb-2">VACCITRACK</h1>
            <p className="col-header">Smart Vaccination Management System</p>
          </div>

          <AnimatePresence mode="wait">
            {isSignUp ? (
              <motion.form 
                key="signup"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                onSubmit={handleSignUp} 
                className="space-y-6"
              >
                <div>
                  <label className="col-header block mb-2">Full Name</label>
                  <input 
                    name="name" 
                    type="text" 
                    required 
                    className="w-full focus:outline-none focus:border-black transition-colors"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label className="col-header block mb-2">Email Address</label>
                  <input 
                    name="email" 
                    type="email" 
                    required 
                    className="w-full focus:outline-none focus:border-black transition-colors"
                    placeholder="john@example.com"
                  />
                </div>
                <div>
                  <label className="col-header block mb-2">Password</label>
                  <input 
                    name="password" 
                    type="password" 
                    required 
                    className="w-full focus:outline-none focus:border-black transition-colors"
                    placeholder="••••••••"
                  />
                </div>
                <div>
                  <label className="col-header block mb-2">Role</label>
                  <select name="role" className="w-full focus:outline-none focus:border-black transition-colors">
                    <option value="Staff">Staff</option>
                    <option value="Admin">Admin</option>
                  </select>
                </div>
                {error && (
                  <p className="text-red-600 text-xs font-mono flex items-center gap-2">
                    <AlertCircle size={14} /> {error}
                  </p>
                )}
                <button 
                  type="submit" 
                  disabled={loading}
                  className="primary w-full py-4 disabled:opacity-50"
                >
                  {loading ? 'CREATING ACCOUNT...' : 'CREATE ACCOUNT'}
                </button>
                <button 
                  type="button"
                  onClick={() => setIsSignUp(false)}
                  className="w-full text-[10px] font-bold uppercase tracking-widest opacity-50 hover:opacity-100 transition-opacity"
                >
                  Already have an account? Log In
                </button>
              </motion.form>
            ) : (
              <motion.form 
                key="login"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onSubmit={handleLogin} 
                className="space-y-6"
              >
                <div>
                  <label className="col-header block mb-2">Email Address</label>
                  <input 
                    name="email" 
                    type="email" 
                    required 
                    className="w-full focus:outline-none focus:border-black transition-colors"
                    placeholder="admin@vaccitrack.com"
                  />
                </div>
                <div>
                  <label className="col-header block mb-2">Password</label>
                  <input 
                    name="password" 
                    type="password" 
                    required 
                    className="w-full focus:outline-none focus:border-black transition-colors"
                    placeholder="••••••••"
                  />
                </div>
                {error && (
                  <p className="text-red-600 text-xs font-mono flex items-center gap-2">
                    <AlertCircle size={14} /> {error}
                  </p>
                )}
                <button 
                  type="submit" 
                  disabled={loading}
                  className="primary w-full py-4 disabled:opacity-50"
                >
                  {loading ? 'AUTHENTICATING...' : 'ACCESS SYSTEM'}
                </button>
                <button 
                  type="button"
                  onClick={() => setIsSignUp(true)}
                  className="w-full text-[10px] font-bold uppercase tracking-widest opacity-50 hover:opacity-100 transition-opacity"
                >
                  Don't have an account? Sign Up
                </button>
              </motion.form>
            )}
          </AnimatePresence>
          
          <div className="mt-8 pt-8 border-t border-black/5 text-center">
            <p className="text-[10px] text-black/40 uppercase tracking-widest">
              Authorized Personnel Only • Secure JDBC Connection Active
            </p>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="w-64 border-r border-black/10 flex flex-col bg-white">
        <div className="p-8 border-bottom border-black/10">
          <h2 className="text-xl font-bold tracking-tighter">VACCITRACK</h2>
          <p className="text-[10px] opacity-50 uppercase tracking-widest mt-1">
            {user.role} Session
          </p>
        </div>
        
        <nav className="flex-1 py-4">
          <SidebarItem 
            icon={LayoutDashboard} 
            label="Dashboard" 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
          />
          <SidebarItem 
            icon={Syringe} 
            label="Inventory" 
            active={activeTab === 'inventory'} 
            onClick={() => setActiveTab('inventory')} 
          />
          <SidebarItem 
            icon={Users} 
            label="Citizens" 
            active={activeTab === 'citizens'} 
            onClick={() => setActiveTab('citizens')} 
          />
          <SidebarItem 
            icon={Calendar} 
            label="Appointments" 
            active={activeTab === 'appointments'} 
            onClick={() => setActiveTab('appointments')} 
          />
          <SidebarItem 
            icon={CheckCircle2} 
            label="Vaccinations" 
            active={activeTab === 'vaccinations'} 
            onClick={() => setActiveTab('vaccinations')} 
          />
          <SidebarItem 
            icon={ShieldAlert} 
            label="AEFI Reports" 
            active={activeTab === 'aefi'} 
            onClick={() => setActiveTab('aefi')} 
          />
          <SidebarItem 
            icon={FileBadge} 
            label="Certificates" 
            active={activeTab === 'certificates'} 
            onClick={() => setActiveTab('certificates')} 
          />
        </nav>

        <div className="p-6 border-t border-black/10">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 bg-black text-white flex items-center justify-center text-xs font-bold">
              {user.name[0]}
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-bold truncate">{user.name}</p>
              <p className="text-[10px] opacity-50 truncate">{user.email}</p>
            </div>
          </div>
          <button 
            onClick={() => setUser(null)}
            className="w-full flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-red-600 hover:opacity-70 transition-opacity"
          >
            <LogOut size={14} /> Log Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto p-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'dashboard' && (
              <div className="space-y-12">
                <header>
                  <h1 className="text-5xl font-light tracking-tighter">System Overview</h1>
                  <p className="col-header mt-2">Real-time vaccination statistics and metrics</p>
                </header>

                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
                  <StatCard label="Total Vaccines" value={stats?.vaccines || 0} icon={Syringe} />
                  <StatCard label="Registered Citizens" value={stats?.citizens || 0} icon={Users} />
                  <StatCard label="Vaccinations Done" value={stats?.vaccinations || 0} icon={CheckCircle2} />
                  <StatCard label="Pending Appointments" value={stats?.appointments || 0} icon={Calendar} />
                  <StatCard label="AEFI Reports" value={stats?.aefi || 0} icon={ShieldAlert} />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <section className="bg-white p-8 border border-black/10">
                    <h3 className="col-header mb-6">Recent Vaccinations</h3>
                    <div className="space-y-4">
                      {vaccinations.slice(-5).reverse().map(v => (
                        <div key={v.id} className="flex justify-between items-center py-2 border-b border-black/5">
                          <div>
                            <p className="text-sm font-bold">{v.citizen_name}</p>
                            <p className="text-[10px] opacity-50 uppercase tracking-widest">
                              {v.vaccine_name} • Dose {v.dose_number}
                            </p>
                          </div>
                          <p className="data-value text-xs">{v.vaccination_date}</p>
                        </div>
                      ))}
                      {vaccinations.length === 0 && <p className="text-xs opacity-40 italic">No records found</p>}
                    </div>
                  </section>

                  <section className="bg-white p-8 border border-black/10">
                    <h3 className="col-header mb-6">Critical Stock Alerts</h3>
                    <div className="space-y-4">
                      {vaccines.filter(v => v.quantity < 50).map(v => (
                        <div key={v.id} className="flex justify-between items-center py-2 border-b border-black/5">
                          <div>
                            <p className="text-sm font-bold">{v.name}</p>
                            <p className="text-[10px] text-red-600 font-bold uppercase tracking-widest">
                              Low Stock Warning
                            </p>
                          </div>
                          <p className="data-value text-xs font-bold text-red-600">{v.quantity} units</p>
                        </div>
                      ))}
                      {vaccines.filter(v => v.quantity < 50).length === 0 && (
                        <p className="text-xs opacity-40 italic">All stock levels healthy</p>
                      )}
                    </div>
                  </section>
                </div>
              </div>
            )}

            {activeTab === 'inventory' && (
              <InventoryView 
                vaccines={vaccines} 
                onUpdate={fetchDashboardData} 
                isAdmin={user.role === 'Admin'} 
              />
            )}

            {activeTab === 'citizens' && (
              <CitizensView 
                citizens={citizens} 
                onUpdate={fetchDashboardData} 
              />
            )}

            {activeTab === 'appointments' && (
              <AppointmentsView 
                appointments={appointments} 
                citizens={citizens}
                vaccines={vaccines}
                onUpdate={fetchDashboardData} 
              />
            )}

            {activeTab === 'vaccinations' && (
              <VaccinationsView 
                vaccinations={vaccinations} 
                citizens={citizens}
                vaccines={vaccines}
                onUpdate={fetchDashboardData} 
                onViewCert={(id: number) => {
                  setSelectedCertId(id);
                  setActiveTab('certificates');
                }}
              />
            )}

            {activeTab === 'aefi' && (
              <AEFIView 
                reports={aefi} 
                citizens={citizens}
                onUpdate={fetchDashboardData} 
              />
            )}

            {activeTab === 'certificates' && (
              <CertificatesView 
                vaccinations={vaccinations} 
                selectedId={selectedCertId}
                onSelect={setSelectedCertId}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

// --- Sub-Views ---

const InventoryView = ({ vaccines, onUpdate, isAdmin }: any) => {
  const [showAdd, setShowAdd] = useState(false);

  const handleAdd = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData);
    await fetch('/api/vaccines', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    setShowAdd(false);
    onUpdate();
  };

  const handleDelete = async (id: number) => {
    if (confirm('Delete this vaccine record?')) {
      await fetch(`/api/vaccines/${id}`, { method: 'DELETE' });
      onUpdate();
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <header>
          <h1 className="text-5xl font-light tracking-tighter">Vaccine Inventory</h1>
          <p className="col-header mt-2">Manage vaccine stock and manufacturers</p>
        </header>
        {isAdmin && (
          <button onClick={() => setShowAdd(!showAdd)} className="primary flex items-center gap-2">
            <Plus size={16} /> Add Vaccine
          </button>
        )}
      </div>

      {showAdd && (
        <motion.form 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleAdd} 
          className="grid grid-cols-4 gap-4 p-6 bg-white border border-black/10"
        >
          <input name="name" placeholder="Vaccine Name" required />
          <input name="manufacturer" placeholder="Manufacturer" required />
          <input name="quantity" type="number" placeholder="Quantity" required />
          <input name="expiry_date" type="date" required />
          <div className="col-span-4 flex justify-end gap-2">
            <button type="button" onClick={() => setShowAdd(false)} className="secondary">Cancel</button>
            <button type="submit" className="primary">Save Record</button>
          </div>
        </motion.form>
      )}

      <div className="bg-white border border-black/10">
        <div className="grid grid-cols-5 p-4 border-b border-black/10 bg-black/5">
          <span className="col-header">Name</span>
          <span className="col-header">Manufacturer</span>
          <span className="col-header">Stock Level</span>
          <span className="col-header">Expiry Date</span>
          <span className="col-header">Actions</span>
        </div>
        {vaccines.map((v: Vaccine) => (
          <div key={v.id} className="grid grid-cols-5 p-4 data-row items-center">
            <span className="text-sm font-bold">{v.name}</span>
            <span className="text-sm opacity-60">{v.manufacturer}</span>
            <span className={`data-value text-sm ${v.quantity < 50 ? 'text-red-600 font-bold' : ''}`}>
              {v.quantity} units
            </span>
            <span className="data-value text-xs">{v.expiry_date}</span>
            <div className="flex gap-2">
              {isAdmin && (
                <button onClick={() => handleDelete(v.id)} className="text-red-600 hover:opacity-50">
                  <Trash2 size={16} />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const CitizensView = ({ citizens, onUpdate }: any) => {
  const [showAdd, setShowAdd] = useState(false);

  const handleAdd = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData);
    await fetch('/api/citizens', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    setShowAdd(false);
    onUpdate();
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <header>
          <h1 className="text-5xl font-light tracking-tighter">Citizen Registry</h1>
          <p className="col-header mt-2">Manage registered citizens for vaccination</p>
        </header>
        <button onClick={() => setShowAdd(!showAdd)} className="primary flex items-center gap-2">
          <Plus size={16} /> Register Citizen
        </button>
      </div>

      {showAdd && (
        <motion.form 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleAdd} 
          className="grid grid-cols-3 gap-4 p-6 bg-white border border-black/10"
        >
          <input name="full_name" placeholder="Full Name" required />
          <input name="dob" type="date" required />
          <select name="gender" required>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
          <input name="phone" placeholder="Phone Number" required />
          <input name="address" placeholder="Address" className="col-span-2" required />
          <div className="col-span-3 flex justify-end gap-2">
            <button type="button" onClick={() => setShowAdd(false)} className="secondary">Cancel</button>
            <button type="submit" className="primary">Register</button>
          </div>
        </motion.form>
      )}

      <div className="bg-white border border-black/10">
        <div className="grid grid-cols-5 p-4 border-b border-black/10 bg-black/5">
          <span className="col-header">Full Name</span>
          <span className="col-header">DOB</span>
          <span className="col-header">Gender</span>
          <span className="col-header">Phone</span>
          <span className="col-header">Address</span>
        </div>
        {citizens.map((c: Citizen) => (
          <div key={c.id} className="grid grid-cols-5 p-4 data-row items-center">
            <span className="text-sm font-bold">{c.full_name}</span>
            <span className="data-value text-xs">{c.dob}</span>
            <span className="text-xs uppercase tracking-widest opacity-60">{c.gender}</span>
            <span className="data-value text-xs">{c.phone}</span>
            <span className="text-xs truncate pr-4">{c.address}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const AppointmentsView = ({ appointments, citizens, vaccines, onUpdate }: any) => {
  const [showAdd, setShowAdd] = useState(false);
  const [error, setError] = useState('');

  const handleAdd = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData);
    
    const res = await fetch('/api/appointments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (res.ok) {
      setShowAdd(false);
      onUpdate();
    } else {
      const err = await res.json();
      setError(err.error);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <header>
          <h1 className="text-5xl font-light tracking-tighter">Appointments</h1>
          <p className="col-header mt-2">Schedule and track vaccination sessions</p>
        </header>
        <button onClick={() => setShowAdd(!showAdd)} className="primary flex items-center gap-2">
          <Plus size={16} /> New Appointment
        </button>
      </div>

      {showAdd && (
        <motion.form 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleAdd} 
          className="grid grid-cols-3 gap-4 p-6 bg-white border border-black/10"
        >
          <select name="citizen_id" required>
            <option value="">Select Citizen</option>
            {citizens.map((c: any) => <option key={c.id} value={c.id}>{c.full_name}</option>)}
          </select>
          <select name="vaccine_id" required>
            <option value="">Select Vaccine</option>
            {vaccines.map((v: any) => <option key={v.id} value={v.id}>{v.name} ({v.quantity} left)</option>)}
          </select>
          <input name="appointment_date" type="datetime-local" required />
          {error && <p className="col-span-3 text-red-600 text-[10px] font-bold uppercase">{error}</p>}
          <div className="col-span-3 flex justify-end gap-2">
            <button type="button" onClick={() => setShowAdd(false)} className="secondary">Cancel</button>
            <button type="submit" className="primary">Schedule</button>
          </div>
        </motion.form>
      )}

      <div className="bg-white border border-black/10">
        <div className="grid grid-cols-5 p-4 border-b border-black/10 bg-black/5">
          <span className="col-header">Citizen</span>
          <span className="col-header">Vaccine</span>
          <span className="col-header">Date & Time</span>
          <span className="col-header">Status</span>
          <span className="col-header">Actions</span>
        </div>
        {appointments.map((a: Appointment) => (
          <div key={a.id} className="grid grid-cols-5 p-4 data-row items-center">
            <span className="text-sm font-bold">{a.citizen_name}</span>
            <span className="text-sm opacity-60">{a.vaccine_name}</span>
            <span className="data-value text-xs">{a.appointment_date}</span>
            <span className={`text-[10px] font-bold uppercase tracking-widest ${
              a.status === 'Scheduled' ? 'text-blue-600' : 
              a.status === 'Completed' ? 'text-green-600' : 'text-red-600'
            }`}>
              {a.status}
            </span>
            <div className="flex gap-2">
              {/* Actions like Complete/Cancel could go here */}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const VaccinationsView = ({ vaccinations, citizens, vaccines, onUpdate, onViewCert }: any) => {
  const [showAdd, setShowAdd] = useState(false);
  const [error, setError] = useState('');

  const handleAdd = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData);
    
    const res = await fetch('/api/vaccinations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (res.ok) {
      setShowAdd(false);
      onUpdate();
    } else {
      const err = await res.json();
      setError(err.error);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <header>
          <h1 className="text-5xl font-light tracking-tighter">Vaccination Records</h1>
          <p className="col-header mt-2">Transactional records of administered doses</p>
        </header>
        <button onClick={() => setShowAdd(!showAdd)} className="primary flex items-center gap-2">
          <Plus size={16} /> Record Vaccination
        </button>
      </div>

      {showAdd && (
        <motion.form 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleAdd} 
          className="grid grid-cols-4 gap-4 p-6 bg-white border border-black/10"
        >
          <select name="citizen_id" required>
            <option value="">Select Citizen</option>
            {citizens.map((c: any) => <option key={c.id} value={c.id}>{c.full_name}</option>)}
          </select>
          <select name="vaccine_id" required>
            <option value="">Select Vaccine</option>
            {vaccines.map((v: any) => <option key={v.id} value={v.id}>{v.name}</option>)}
          </select>
          <input name="dose_number" type="number" placeholder="Dose #" required />
          <input name="vaccination_date" type="date" required />
          {error && <p className="col-span-4 text-red-600 text-[10px] font-bold uppercase">{error}</p>}
          <div className="col-span-4 flex justify-end gap-2">
            <button type="button" onClick={() => setShowAdd(false)} className="secondary">Cancel</button>
            <button type="submit" className="primary">Commit Transaction</button>
          </div>
        </motion.form>
      )}

      <div className="bg-white border border-black/10">
        <div className="grid grid-cols-6 p-4 border-b border-black/10 bg-black/5">
          <span className="col-header">Citizen</span>
          <span className="col-header">Vaccine</span>
          <span className="col-header">Dose</span>
          <span className="col-header">Date</span>
          <span className="col-header">Status</span>
          <span className="col-header text-right">Certificate</span>
        </div>
        {vaccinations.map((v: Vaccination) => (
          <div key={v.id} className="grid grid-cols-6 p-4 data-row items-center">
            <span className="text-sm font-bold">{v.citizen_name}</span>
            <span className="text-sm opacity-60">{v.vaccine_name}</span>
            <span className="data-value text-xs">Dose #{v.dose_number}</span>
            <span className="data-value text-xs">{v.vaccination_date}</span>
            <span className="text-[10px] font-bold uppercase tracking-widest text-green-600">
              Verified
            </span>
            <div className="flex justify-end">
              <button 
                onClick={() => onViewCert(v.id)}
                className="text-black/40 hover:text-black transition-colors"
              >
                <FileBadge size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const AEFIView = ({ reports, citizens, onUpdate }: any) => {
  const [showAdd, setShowAdd] = useState(false);

  const handleAdd = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData);
    await fetch('/api/aefi', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    setShowAdd(false);
    onUpdate();
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <header>
          <h1 className="text-5xl font-light tracking-tighter">AEFI Reports</h1>
          <p className="col-header mt-2">Adverse Events Following Immunization</p>
        </header>
        <button onClick={() => setShowAdd(!showAdd)} className="primary flex items-center gap-2">
          <Plus size={16} /> New AEFI Report
        </button>
      </div>

      {showAdd && (
        <motion.form 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleAdd} 
          className="grid grid-cols-2 gap-4 p-6 bg-white border border-black/10"
        >
          <select name="citizen_id" required>
            <option value="">Select Citizen</option>
            {citizens.map((c: any) => <option key={c.id} value={c.id}>{c.full_name}</option>)}
          </select>
          <input name="report_date" type="date" required />
          <textarea name="description" placeholder="Description of adverse reaction" className="col-span-2 h-32" required />
          <div className="col-span-2 flex justify-end gap-2">
            <button type="button" onClick={() => setShowAdd(false)} className="secondary">Cancel</button>
            <button type="submit" className="primary">Submit Report</button>
          </div>
        </motion.form>
      )}

      <div className="bg-white border border-black/10">
        <div className="grid grid-cols-4 p-4 border-b border-black/10 bg-black/5">
          <span className="col-header">Citizen</span>
          <span className="col-header">Description</span>
          <span className="col-header">Date</span>
          <span className="col-header">Severity</span>
        </div>
        {reports.map((r: AEFIReport) => (
          <div key={r.id} className="grid grid-cols-4 p-4 data-row items-start">
            <span className="text-sm font-bold">{r.citizen_name}</span>
            <span className="text-xs pr-8 leading-relaxed opacity-80">{r.description}</span>
            <span className="data-value text-xs">{r.report_date}</span>
            <span className="text-[10px] font-bold uppercase tracking-widest text-red-600">
              Alert
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

const CertificatesView = ({ vaccinations, selectedId, onSelect }: any) => {
  const selectedCert = vaccinations.find((v: any) => v.id === selectedId);

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-5xl font-light tracking-tighter">Vaccination Certificates</h1>
        <p className="col-header mt-2">Generate and view official vaccination proof</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-1 bg-white border border-black/10 h-[600px] overflow-auto">
          <div className="p-4 border-b border-black/10 bg-black/5">
            <p className="col-header">Available Certificates</p>
          </div>
          {vaccinations.map((v: Vaccination) => (
            <button 
              key={v.id} 
              onClick={() => onSelect(v.id)}
              className={`w-full text-left p-4 data-row transition-colors ${selectedCert?.id === v.id ? 'bg-black/5' : ''}`}
            >
              <p className="text-sm font-bold">{v.citizen_name}</p>
              <p className="text-[10px] opacity-50 uppercase tracking-widest">
                {v.vaccine_name} • Dose {v.dose_number}
              </p>
              <p className="data-value text-[10px] mt-1">{v.vaccination_date}</p>
            </button>
          ))}
          {vaccinations.length === 0 && (
            <div className="p-8 text-center opacity-40 italic text-sm">
              No vaccinations recorded yet.
            </div>
          )}
        </div>

        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            {selectedCert ? (
              <motion.div 
                key={selectedCert.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white border-4 border-black p-12 shadow-2xl relative overflow-hidden"
              >
                {/* Decorative Elements */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-black/5 -mr-16 -mt-16 rotate-45" />
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-black/5 -ml-16 -mb-16 rotate-45" />

                <div className="text-center mb-12">
                  <div className="inline-block p-3 border-2 border-black mb-4">
                    <FileBadge size={48} />
                  </div>
                  <h2 className="text-3xl font-bold tracking-tighter uppercase">Certificate of Vaccination</h2>
                  <p className="col-header mt-2">Official Health Record • VacciTrack System</p>
                </div>

                <div className="space-y-8 border-y border-black/10 py-12">
                  <div className="grid grid-cols-2 gap-12">
                    <div>
                      <p className="col-header mb-1">Recipient Name</p>
                      <p className="text-xl font-bold">{selectedCert.citizen_name}</p>
                    </div>
                    <div>
                      <p className="col-header mb-1">Certificate ID</p>
                      <p className="data-value text-sm">VT-{selectedCert.id}-{Math.random().toString(36).substring(7).toUpperCase()}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-12">
                    <div>
                      <p className="col-header mb-1">Vaccine Administered</p>
                      <p className="text-lg">{selectedCert.vaccine_name}</p>
                    </div>
                    <div>
                      <p className="col-header mb-1">Dose Number</p>
                      <p className="text-lg">Dose {selectedCert.dose_number}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-12">
                    <div>
                      <p className="col-header mb-1">Date of Vaccination</p>
                      <p className="data-value">{selectedCert.vaccination_date}</p>
                    </div>
                    <div>
                      <p className="col-header mb-1">Issuing Authority</p>
                      <p className="text-sm">VacciTrack Digital Health Network</p>
                    </div>
                  </div>
                </div>

                <div className="mt-12 flex justify-between items-end">
                  <div className="w-24 h-24 border border-black/20 flex items-center justify-center bg-black/5">
                    <div className="grid grid-cols-3 gap-1">
                      {[...Array(9)].map((_, i) => (
                        <div key={i} className="w-4 h-4 bg-black/20" />
                      ))}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="col-header mb-4">Digital Signature</p>
                    <div className="h-px w-48 bg-black mb-2" />
                    <p className="text-[10px] font-mono opacity-50">VERIFIED BY VACCITRACK SECURE NODE</p>
                  </div>
                </div>

                <div className="mt-12 text-center">
                  <button 
                    onClick={() => window.print()}
                    className="primary flex items-center gap-2 mx-auto no-print"
                  >
                    Print Certificate
                  </button>
                </div>
              </motion.div>
            ) : (
              <div className="h-full flex items-center justify-center border-2 border-dashed border-black/10 p-12 text-center">
                <div>
                  <FileBadge size={64} className="mx-auto mb-4 opacity-10" />
                  <p className="col-header">Select a record to view certificate</p>
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
