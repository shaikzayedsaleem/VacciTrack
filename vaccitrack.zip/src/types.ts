export interface User {
  id: number;
  name: string;
  email: string;
  role: 'Admin' | 'Staff';
}

export interface Vaccine {
  id: number;
  name: string;
  manufacturer: string;
  quantity: number;
  expiry_date: string;
}

export interface Citizen {
  id: number;
  full_name: string;
  dob: string;
  gender: string;
  phone: string;
  address: string;
}

export interface Appointment {
  id: number;
  citizen_id: number;
  citizen_name?: string;
  vaccine_id: number;
  vaccine_name?: string;
  appointment_date: string;
  status: 'Scheduled' | 'Completed' | 'Cancelled';
}

export interface Vaccination {
  id: number;
  citizen_id: number;
  citizen_name?: string;
  vaccine_id: number;
  vaccine_name?: string;
  dose_number: number;
  vaccination_date: string;
}

export interface AEFIReport {
  id: number;
  citizen_id: number;
  citizen_name?: string;
  description: string;
  report_date: string;
}

export interface DashboardStats {
  vaccines: number;
  citizens: number;
  vaccinations: number;
  appointments: number;
  aefi: number;
}
