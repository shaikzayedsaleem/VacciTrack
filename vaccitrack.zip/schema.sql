-- VacciTrack Database Schema (MySQL/SQLite compatible)

-- Users table for authentication and role-based access
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT CHECK(role IN ('Admin', 'Staff')) NOT NULL
);

-- Vaccine inventory management
CREATE TABLE vaccines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    manufacturer TEXT NOT NULL,
    quantity INTEGER DEFAULT 0,
    expiry_date TEXT NOT NULL
);

-- Citizen registration
CREATE TABLE citizens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    dob TEXT NOT NULL,
    gender TEXT NOT NULL,
    phone TEXT NOT NULL,
    address TEXT NOT NULL
);

-- Appointment scheduling
CREATE TABLE appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    citizen_id INTEGER NOT NULL,
    vaccine_id INTEGER NOT NULL,
    appointment_date TEXT NOT NULL,
    status TEXT CHECK(status IN ('Scheduled', 'Completed', 'Cancelled')) DEFAULT 'Scheduled',
    FOREIGN KEY (citizen_id) REFERENCES citizens(id),
    FOREIGN KEY (vaccine_id) REFERENCES vaccines(id)
);

-- Vaccination records (Transactional)
CREATE TABLE vaccinations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    citizen_id INTEGER NOT NULL,
    vaccine_id INTEGER NOT NULL,
    dose_number INTEGER NOT NULL,
    vaccination_date TEXT NOT NULL,
    FOREIGN KEY (citizen_id) REFERENCES citizens(id),
    FOREIGN KEY (vaccine_id) REFERENCES vaccines(id)
);

-- AEFI (Adverse Events Following Immunization) reports
CREATE TABLE aefi_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    citizen_id INTEGER NOT NULL,
    description TEXT NOT NULL,
    report_date TEXT NOT NULL,
    FOREIGN KEY (citizen_id) REFERENCES citizens(id)
);

-- Initial Admin User (Password: admin123)
-- Note: Password should be hashed using SHA-256: 
-- 240be518fabd2724ddb6f0403011365730078d60423ad2f6961f00d469923607
INSERT INTO users (name, email, password, role) 
VALUES ('System Admin', 'admin@vaccitrack.com', '240be518fabd2724ddb6f0403011365730078d60423ad2f6961f00d469923607', 'Admin');
